# JS-Clicker
This is a small Cookie Clicker-esque game made entirely in HTML, CSS, and JS :)
Play now at: https://lee1248.github.io/Js-Clicker/
